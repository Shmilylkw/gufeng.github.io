<div class="container">
  <?php get_template_part( 'parts/single-header' ); ?>
</div>